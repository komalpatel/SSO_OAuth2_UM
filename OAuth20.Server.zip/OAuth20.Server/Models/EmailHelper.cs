﻿using System;
using System.Net.Http;
using System.Net.Mail;

namespace OAuth20.Server.Models
{
    public class EmailHelper
    {

        //smtpClient.SendCompleted += (s, e) =>
        //    {
        //        netmail.Dispose();
        //        smtpClient.Dispose();
        //        if (!e.Cancelled && e.Error == null)
        //        {
        //        }
        //        else
        //        {
        //        }
        //    };
        //    //smtpClient.Send(netmail);
        //    //return null;
        //    return smtpClient.SendMailAsync(netmail);


        public bool SendEmailPasswordReset(string userEmail, string link)
        {
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("noreply@chargeatfriends.com");
            mailMessage.To.Add(new MailAddress(userEmail));

            mailMessage.Subject = "Password Reset";
            mailMessage.IsBodyHtml = true;
            mailMessage.Body = link;

            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("noreply@chargeatfriends.com", "F880704A-6A86-$AD0-A94A");
            client.Host = "smtps.udag.de";
            client.Port = 587;
            client.UseDefaultCredentials = false;
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;

            client.SendCompleted += (s, e) =>
            {
                mailMessage.Dispose();
                client.Dispose();
                if (!e.Cancelled && e.Error == null)
                {

                }
                else
                {

                }
            };
        

            try
            {
                client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                // log exception
            }
            return false;
        }
    }
}
