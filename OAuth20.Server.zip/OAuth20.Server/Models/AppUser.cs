﻿using Microsoft.AspNetCore.Identity;

namespace OAuth20.Server.Models
{
    public class AppUser : IdentityUser
    {
    }
}
